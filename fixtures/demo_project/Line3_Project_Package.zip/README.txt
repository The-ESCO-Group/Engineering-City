SYNTHETIC FIXTURE package for Conveyor Line 3.
Contains invented engineering documents for testing only.
